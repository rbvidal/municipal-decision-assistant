# Navigation Design

## Design Goals

The navigation must:
- Put work first, not features
- Show the user where they are and what needs attention
- Separate daily work from administration
- Never hide the primary action path behind menus
- Work at 1280-1920px with persistent visibility

## Primary Navigation

```
┌──────────────────────────────────────────────────────────────────────────────┐
│  [Municipality Logo]  Municipal Decision Platform           [🔔] [👤 Müller] │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ● Startseite    ● Meine Arbeit    ● Wissen    ● Dokumente    ● Verwaltung   │
│                                                                              │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  (page content)                                                              │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Navigation Items

| Label | Route | Purpose |
|---|---|---|
| **Startseite** | `/home` | Today's work overview. What needs my attention right now. |
| **Meine Arbeit** | `/work` | Case inbox, active cases, draft decisions, approval queue, archive |
| **Wissen** | `/knowledge` | Regulations, procedures, templates, checklists, search |
| **Dokumente** | `/documents` | Document management, upload, version history, indexing status |
| **Verwaltung** | `/admin` | Corpus health, audit, jobs, benchmarks, system configuration |

### Why This Structure

**Startseite (Home):** Opens with work, not AI. The user sees their workload immediately — pending applications, deadlines, urgent tasks. The AI input is available but secondary. This is the opposite of ChatGPT's blank prompt.

**Meine Arbeit (My Work):** The heart of the product. A unified workspace that follows the complete case lifecycle — inbox to archive. This is where the Sachbearbeiter spends 80% of their day.

**Wissen (Knowledge):** Regulations and procedures separated from case work. When the user needs to look something up without a specific case context, this is where they go. Search is prominent here.

**Dokumente (Documents):** Document lifecycle management. Upload, metadata, versioning, indexing. Separated from Knowledge because managing documents is a different mental mode than consulting them.

**Verwaltung (Administration):** Everything technical. Corpus health, audit logs, jobs, benchmarks, developer tools. None of this belongs in the main workflow. Normal Sachbearbeiter may never click this.

### What Changed From the Old Navigation

| Old | New | Why |
|---|---|---|
| `/decision` | Integrated into Startseite + Meine Arbeit | AI is a tool within workflow, not a standalone page |
| `/cases` | Meine Arbeit | Cases are the work, not a separate concept |
| `/regulations` | Wissen | Broader concept — includes procedures, templates, FAQs |
| `/search` | Integrated into Wissen + Documents | Search is a capability everywhere, not a page |
| `/workspaces` | Removed from main nav | Workspaces are a configuration concept in Verwaltung |
| `/graph` | Verwaltung (sub-page) | Knowledge graph is an admin/advanced feature |
| `/analytics` | Verwaltung (sub-page) | Analytics is admin, not daily work |
| `/audit` | Verwaltung (sub-page) | Audit is admin |
| `/jobs` | Verwaltung (sub-page) | Jobs is admin |

## Secondary Navigation

### Meine Arbeit sub-navigation

```
[ Posteingang (3) ]  [ Offene Vorgänge (12) ]  [ Genehmigung (2) ]  [ Archiv ]
```

### Wissen sub-navigation

```
[ Suche ]  [ Vorschriften ]  [ Verfahren ]  [ Vorlagen ]  [ FAQs ]
```

### Dokumente sub-navigation

```
[ Alle Dokumente ]  [ Hochladen ]  [ Index-Status ]
```

### Verwaltung sub-navigation

```
[ Übersicht ]  [ Korpus-Status ]  [ Audit ]  [ Aufträge ]  [ Benchmarks ]  [ Entwickler ]
```

## Top Bar

Right side of the top bar:

| Element | Purpose |
|---|---|
| Notification bell (🔔) | System notifications, job completions, alerts. Badge with count. |
| User menu (👤 Name) | Profile, Change Password, Language (DE/EN), Logout |

## Breadcrumb

Every page shows a breadcrumb:

```
Startseite > Meine Arbeit > Vorgang #2026-0147 > Entscheidungsentwurf
```

## Responsive Behavior

**1920px (Full HD):** Full navigation visible. Side panels where applicable. Tables at maximum density.

**1366px (Laptop):** Full navigation visible. Side panels collapse to icons or toggle. Tables reduce to essential columns.

**Tablet:** Not a target platform. Navigation collapses to hamburger. Read-only view of case status. No document editing.

**Mobile:** Not supported in v1.0. Municipal employees use desktop workstations.
